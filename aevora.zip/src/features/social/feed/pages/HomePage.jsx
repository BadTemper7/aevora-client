import { useState } from "react";
import {
  Image,
  Video,
  Smile,
  MoreHorizontal,
  Heart,
  MessageCircle,
  Share2,
  Plus,
  Globe,
} from "lucide-react";

const stories = [
  { name: "Your Story", color: "from-blue-500 to-violet-500", own: true },
  { name: "Alex Morgan", color: "from-pink-500 to-orange-400" },
  { name: "Sarah Williams", color: "from-violet-500 to-blue-500" },
  { name: "Daniel Cruz", color: "from-emerald-500 to-cyan-500" },
  { name: "Emma Wilson", color: "from-amber-500 to-red-500" },
];

const initialPosts = [
  {
    id: 1,
    name: "Alex Morgan",
    username: "@alexmorgan",
    time: "2 hours ago",
    avatar: "A",
    content:
      "Excited to see what everyone is building today! New ideas, new connections, and new opportunities. 🚀",
    likes: 128,
    comments: 24,
    color: "from-pink-500 to-orange-400",
  },
];

function HomePage() {
  const [posts, setPosts] = useState(initialPosts);
  const [postContent, setPostContent] = useState("");
  const [likedPosts, setLikedPosts] = useState([]);

  const handleCreatePost = () => {
    if (!postContent.trim()) return;

    const newPost = {
      id: Date.now(),
      name: "Your Name",
      username: "@youraccount",
      time: "Just now",
      avatar: "R",
      content: postContent.trim(),
      likes: 0,
      comments: 0,
      color: "from-blue-500 to-violet-500",
    };

    setPosts((current) => [newPost, ...current]);
    setPostContent("");
  };

  const toggleLike = (postId) => {
    setLikedPosts((current) =>
      current.includes(postId)
        ? current.filter((id) => id !== postId)
        : [...current, postId],
    );
  };

  return (
    <div className="mx-auto max-w-[760px] space-y-6 pb-12">
      {/* Page Heading */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-aevora-muted">Welcome back</p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight">Your Feed</h1>
        </div>

        <button className="rounded-xl border border-aevora-border bg-aevora-surface px-4 py-2 text-sm text-aevora-muted hover:border-aevora-primary">
          <Globe size={16} className="mr-2 inline" />
          Everyone
        </button>
      </div>

      {/* Stories */}
      <section className="rounded-2xl border border-aevora-border bg-aevora-surface p-4">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-semibold">Stories</h2>
          <button className="text-xs text-aevora-primary hover:text-blue-400">
            View all
          </button>
        </div>

        <div className="flex gap-4 overflow-x-auto pb-2">
          {stories.map((story) => (
            <button
              key={story.name}
              className="flex min-w-[76px] flex-col items-center gap-2"
            >
              <div
                className={`relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br ${story.color} p-[3px]`}
              >
                <div className="flex h-full w-full items-center justify-center rounded-full border-[3px] border-aevora-surface bg-aevora-elevated text-lg font-bold">
                  {story.own ? <Plus size={24} /> : story.name[0]}
                </div>
              </div>

              <span className="w-full truncate text-center text-xs text-aevora-muted">
                {story.name}
              </span>
            </button>
          ))}
        </div>
      </section>

      {/* Create Post */}
      <section className="rounded-2xl border border-aevora-border bg-aevora-surface p-5">
        <div className="flex gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-600 font-bold">
            R
          </div>

          <textarea
            value={postContent}
            onChange={(event) => setPostContent(event.target.value)}
            placeholder="Share something with your world..."
            rows={3}
            className="w-full resize-none rounded-xl border border-aevora-border bg-aevora-bg p-3 text-sm outline-none transition placeholder:text-aevora-muted focus:border-aevora-primary"
          />
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-aevora-border pt-4">
          <div className="flex gap-4">
            <button className="flex items-center gap-2 text-xs text-aevora-muted hover:text-emerald-400">
              <Image size={18} />
              Photo
            </button>

            <button className="flex items-center gap-2 text-xs text-aevora-muted hover:text-blue-400">
              <Video size={18} />
              Video
            </button>

            <button className="flex items-center gap-2 text-xs text-aevora-muted hover:text-amber-400">
              <Smile size={18} />
              Feeling
            </button>
          </div>

          <button
            onClick={handleCreatePost}
            disabled={!postContent.trim()}
            className="rounded-xl bg-aevora-primary px-5 py-2 text-sm font-semibold transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Publish
          </button>
        </div>
      </section>

      {/* Feed Posts */}
      {posts.map((post) => {
        const isLiked = likedPosts.includes(post.id);

        return (
          <article
            key={post.id}
            className="rounded-2xl border border-aevora-border bg-aevora-surface p-5"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br ${post.color} font-bold`}
                >
                  {post.avatar}
                </div>

                <div>
                  <h3 className="text-sm font-semibold">{post.name}</h3>
                  <p className="mt-1 text-xs text-aevora-muted">
                    {post.username} · {post.time}
                  </p>
                </div>
              </div>

              <button className="rounded-lg p-2 text-aevora-muted hover:bg-aevora-elevated hover:text-white">
                <MoreHorizontal size={20} />
              </button>
            </div>

            <p className="my-5 whitespace-pre-wrap text-sm leading-7 text-slate-200">
              {post.content}
            </p>

            <div className="flex items-center justify-between border-t border-aevora-border pt-4 text-xs text-aevora-muted">
              <span>{post.likes + (isLiked ? 1 : 0)} likes</span>
              <span>{post.comments} comments</span>
            </div>

            <div className="mt-3 grid grid-cols-3 gap-2 border-t border-aevora-border pt-3">
              <button
                onClick={() => toggleLike(post.id)}
                className={`flex items-center justify-center gap-2 rounded-lg py-2 text-sm transition hover:bg-aevora-elevated ${
                  isLiked ? "text-pink-400" : "text-aevora-muted"
                }`}
              >
                <Heart size={18} fill={isLiked ? "currentColor" : "none"} />
                Like
              </button>

              <button className="flex items-center justify-center gap-2 rounded-lg py-2 text-sm text-aevora-muted transition hover:bg-aevora-elevated">
                <MessageCircle size={18} />
                Comment
              </button>

              <button className="flex items-center justify-center gap-2 rounded-lg py-2 text-sm text-aevora-muted transition hover:bg-aevora-elevated">
                <Share2 size={18} />
                Share
              </button>
            </div>
          </article>
        );
      })}
    </div>
  );
}

export default HomePage;
