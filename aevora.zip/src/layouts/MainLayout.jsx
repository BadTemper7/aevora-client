import { Outlet, NavLink } from "react-router-dom";
import {
  House,
  Compass,
  Users,
  MessageCircle,
  Bell,
  Clapperboard,
  Play,
  Gamepad2,
  UsersRound,
  Building2,
  CalendarDays,
  CheckSquare,
  Settings,
  Search,
  Plus,
  ChevronDown,
  Sparkles,
} from "lucide-react";

const navigation = [
  {
    title: "MAIN",
    items: [
      { label: "Home", icon: House, path: "/" },
      { label: "Explore", icon: Compass, path: "/explore" },
      { label: "Friends", icon: Users, path: "/friends" },
      { label: "Messages", icon: MessageCircle, path: "/messages" },
      { label: "Notifications", icon: Bell, path: "/notifications" },
    ],
  },
  {
    title: "DISCOVER",
    items: [
      { label: "Short Videos", icon: Clapperboard, path: "/videos" },
      { label: "Watch", icon: Play, path: "/watch" },
      { label: "Gaming", icon: Gamepad2, path: "/gaming" },
      { label: "Communities", icon: UsersRound, path: "/communities" },
    ],
  },
  {
    title: "WORKSPACE",
    items: [
      { label: "Company", icon: Building2, path: "/workspace" },
      { label: "Calendar", icon: CalendarDays, path: "/calendar" },
      { label: "Tasks", icon: CheckSquare, path: "/tasks" },
    ],
  },
];

function MainLayout() {
  return (
    <div className="min-h-screen bg-aevora-bg text-aevora-text">
      {/* Top Navigation */}
      <header className="fixed inset-x-0 top-0 z-50 h-[72px] border-b border-aevora-border bg-aevora-bg/95 backdrop-blur-xl">
        <div className="flex h-full items-center justify-between px-6">
          <div className="flex w-[250px] items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-aevora-primary to-aevora-violet text-xl font-bold shadow-lg shadow-blue-950/40">
              A
            </div>
            <span className="text-xl font-bold tracking-[0.16em]">AEVORA</span>
          </div>

          <div className="hidden max-w-xl flex-1 md:block">
            <div className="flex items-center gap-3 rounded-xl border border-aevora-border bg-aevora-surface px-4 py-3">
              <Search size={18} className="text-aevora-muted" />
              <input
                type="text"
                placeholder="Search people, posts, videos and communities..."
                className="w-full bg-transparent text-sm outline-none placeholder:text-aevora-muted"
              />
              <kbd className="rounded border border-aevora-border px-2 py-1 text-xs text-aevora-muted">
                /
              </kbd>
            </div>
          </div>

          <div className="flex w-[250px] items-center justify-end gap-4">
            <button className="rounded-xl p-2 text-aevora-muted transition hover:bg-aevora-elevated hover:text-white">
              <Plus size={21} />
            </button>

            <button className="relative rounded-xl p-2 text-aevora-muted transition hover:bg-aevora-elevated hover:text-white">
              <Bell size={21} />
              <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-aevora-primary" />
            </button>

            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-600 font-semibold">
                R
              </div>
              <ChevronDown size={15} className="text-aevora-muted" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Application */}
      <div className="mx-auto grid max-w-[1800px] grid-cols-1 gap-6 px-6 pt-[96px] lg:grid-cols-[250px_minmax(0,1fr)] xl:grid-cols-[250px_minmax(0,1fr)_300px]">
        {/* Left Sidebar */}
        <aside className="hidden lg:block">
          <div className="sticky top-[96px] space-y-7">
            {navigation.map((group) => (
              <div key={group.title}>
                <h3 className="mb-3 px-3 text-[10px] font-bold tracking-[0.18em] text-aevora-muted">
                  {group.title}
                </h3>

                <div className="space-y-1">
                  {group.items.map((item) => {
                    const Icon = item.icon;

                    return (
                      <NavLink
                        key={item.label}
                        to={item.path}
                        end={item.path === "/"}
                        className={({ isActive }) =>
                          `flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition ${
                            isActive
                              ? "bg-aevora-primary/15 text-blue-400"
                              : "text-aevora-muted hover:bg-aevora-elevated hover:text-white"
                          }`
                        }
                      >
                        <Icon size={19} />
                        {item.label}
                      </NavLink>
                    );
                  })}
                </div>
              </div>
            ))}

            <div>
              <NavLink
                to="/settings"
                className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-aevora-muted transition hover:bg-aevora-elevated hover:text-white"
              >
                <Settings size={19} />
                Settings
              </NavLink>
            </div>

            <div className="rounded-2xl border border-aevora-border bg-gradient-to-br from-aevora-surface to-aevora-elevated p-4">
              <Sparkles size={20} className="mb-3 text-blue-400" />
              <h3 className="text-sm font-semibold">Discover AEVORA</h3>
              <p className="mt-2 text-xs leading-5 text-aevora-muted">
                Connect, create, play and collaborate in one place.
              </p>
              <button className="mt-4 w-full rounded-lg bg-aevora-primary py-2 text-xs font-semibold transition hover:bg-blue-500">
                Explore features
              </button>
            </div>
          </div>
        </aside>

        {/* Center Content */}
        <main className="min-w-0">
          <Outlet />
        </main>

        {/* Right Sidebar */}
        <aside className="hidden xl:block">
          <div className="sticky top-[96px] space-y-5">
            <section className="rounded-2xl border border-aevora-border bg-aevora-surface p-5">
              <h3 className="font-semibold">Trending now</h3>
              <p className="mt-1 text-xs text-aevora-muted">
                What's happening across AEVORA
              </p>

              {["#Technology", "#Gaming", "#Entertainment", "#Community"].map(
                (tag, index) => (
                  <div
                    key={tag}
                    className="mt-5 flex items-center justify-between"
                  >
                    <div>
                      <p className="text-sm font-medium">{tag}</p>
                      <p className="mt-1 text-xs text-aevora-muted">
                        {12 - index * 2}k posts
                      </p>
                    </div>
                    <span className="text-aevora-muted">···</span>
                  </div>
                ),
              )}
            </section>

            <section className="rounded-2xl border border-aevora-border bg-aevora-surface p-5">
              <h3 className="font-semibold">People you may know</h3>

              {["Alex Morgan", "Sarah Williams", "Daniel Cruz"].map(
                (name, index) => (
                  <div key={name} className="mt-5 flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-600 text-sm font-bold">
                      {name[0]}
                    </div>

                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{name}</p>
                      <p className="text-xs text-aevora-muted">
                        {index + 2} mutual connections
                      </p>
                    </div>

                    <button className="rounded-lg bg-aevora-elevated px-3 py-2 text-xs hover:bg-aevora-primary">
                      Add
                    </button>
                  </div>
                ),
              )}
            </section>

            <p className="px-2 text-xs leading-6 text-aevora-muted">
              About · Privacy · Terms · Help · © 2026 AEVORA
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}

export default MainLayout;
