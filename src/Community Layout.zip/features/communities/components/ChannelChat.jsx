import { useEffect, useMemo, useRef, useState } from 'react';
import { useInfiniteQuery, useQuery, useQueryClient } from '@tanstack/react-query';
import { AlertCircle, Check, ChevronDown, Copy, LoaderCircle, MessageCircleReply, MoreHorizontal, Pin, PinOff, Reply, Search, Trash2, X } from 'lucide-react';
import ChatComposer from '../../social/messaging/ChatComposer';
import EmojiPicker from '../../../components/common/EmojiPicker';
import { mediaFile } from '../../social/api/socialApi';
import { communityCreate,communityRead,communityPatch,communityDelete,communityPut,communityError } from '../api/communityApi';
import { getSocialSocket,subscribeSocialSocket } from '../../../services/socket/socketClient';
import { field,smallButton,ErrorNotice } from '../../social/components/SocialUI';
import { useAuth } from '../../auth/hooks/useAuth';
const quick=['👍','❤️','😆','😮'];
function getAllPages(cache){return cache?.pages?.slice().reverse().flatMap(p=>p.items||[])||[];}
export function mergeCommunityMessage(cache,message,update=false){
  if(!cache?.pages?.length)return cache;
  let found=false;
  const pages=cache.pages.map(p=>({...p,items:p.items.map(m=>{
    if(m.id===message.id || message.clientId && m.clientId===message.clientId){found=true;return {...m,...message};}
    return m;
  })}));
  if(!found&&!update)pages[0]={...pages[0],items:[...pages[0].items,message]};
  return {...cache,pages};
}
function SafeMedia({message}){
  return <div className="flex max-w-full flex-col gap-2">{message.gifUrl&&<img src={message.gifUrl} loading="lazy" alt="Shared GIF" className="max-h-72 max-w-[min(300px,100%)] rounded-lg object-contain"/>}{message.mediaIds?.map(id=><CommunityAttachment key={String(id)} id={String(id)} />)}</div>;
}
function CommunityAttachment({id}){
  // Secure media responses are gated by the existing Better Auth session and channel membership.
  const src=mediaFile(id);
  return <div className="max-w-[min(340px,100%)] overflow-hidden rounded-xl border border-line"><img src={mediaFile(id,true)} alt="Community attachment preview" loading="lazy" className="max-h-64 w-full object-contain" onError={e=>{e.currentTarget.style.display='none';}}/><a href={src} target="_blank" rel="noreferrer" className="block px-3 py-2 text-xs font-semibold text-brand-ink underline">Open attachment</a></div>;
}
function ChatBubble({message,me,canModerate,onReply,onEdit,onChange,threadOpen,onThread}){
  const [menu,setMenu]=useState(false),[emojiOpen,setEmojiOpen]=useState(false),[error,setError]=useState('');
  const anchor=useRef(null);
  const run=async(action)=>{setError('');setMenu(false);try{await action();}catch(err){setError(communityError(err));}};
  const editable=message.senderId===me&&!message.deletedAt;
  const deleted=Boolean(message.deletedAt);
  return <article id={`community-message-${message.id}`} className="group relative flex gap-2 rounded-xl px-2 py-1 hover:bg-raised/60 focus-within:bg-raised/60">
    <div className="grid size-9 shrink-0 place-items-center overflow-hidden rounded-full bg-brand-soft text-sm font-extrabold text-brand-ink">{message.sender?.image?<img src={message.sender.image} alt="" className="size-full object-cover"/>:(message.sender?.name||'U').slice(0,1).toUpperCase()}</div>
    <div className="min-w-0 flex-1"><div className="mb-0.5 flex flex-wrap items-baseline gap-2"><span className="text-sm font-extrabold text-ink">{message.sender?.name||message.sender?.username||'Member'}</span><time className="text-[11px] text-ink-faint">{message.createdAt?new Date(message.createdAt).toLocaleString():''}</time>{message.editedAt&&<span className="text-[11px] text-ink-faint">Edited</span>}{message.pinnedAt&&<span title="Pinned" className="text-xs text-brand-ink"><Pin size={12}/></span>}</div>
      {deleted?<p className="text-sm italic text-ink-faint">Message deleted</p>:<><p className="whitespace-pre-wrap break-words text-sm leading-6 text-ink">{message.content}</p><SafeMedia message={message}/>{message.replyTo&&<p className="text-xs text-ink-soft">↳ Reply to earlier message</p>}</>}
      {message.reactions?.length>0&&<div className="mt-1 flex flex-wrap gap-1">{[...new Set(message.reactions.map(r=>r.emoji))].map(e=><button key={e} onClick={()=>!deleted&&run(()=>onChange('react',message,{emoji:e}))} aria-label={`React ${e}`} className={`rounded-full border px-2 py-0.5 text-xs ${message.reactions.some(r=>r.emoji===e&&r.userId===me)?'border-brand bg-brand-soft':'border-line bg-surface'}`}>{e} {message.reactions.filter(r=>r.emoji===e).length}</button>)}</div>}
      {message.optimistic&&<span className="text-[11px] text-ink-faint">{message.failed?'Failed to send':'Sending...'}</span>}
      {message.failed&&<button className="ml-2 text-xs text-danger underline" onClick={()=>onChange('retry',message)}>Retry</button>}
      {error&&<p role="alert" className="text-xs text-danger">{error}</p>}
    </div>
    {!deleted&&!message.optimistic&&<div className="absolute -top-4 right-1 hidden items-center gap-1 rounded-xl border border-line bg-surface p-1 shadow-md group-hover:flex group-focus-within:flex">
      {quick.map(e=><button key={e} type="button" aria-label={`React ${e}`} title={`React ${e}`} className="rounded-md p-1 text-sm hover:bg-raised" onClick={()=>run(()=>onChange('react',message,{emoji:e}))}>{e}</button>)}
      <div className="relative"><button ref={anchor} type="button" aria-label="More emoji reactions" onClick={()=>setEmojiOpen(v=>!v)} className="rounded-md px-1 text-ink-soft hover:bg-raised">+</button><EmojiPicker open={emojiOpen} anchorRef={anchor} onClose={()=>setEmojiOpen(false)} onSelect={e=>{setEmojiOpen(false);run(()=>onChange('react',message,{emoji:e}));}}/></div>
      <button type="button" title="Reply" aria-label="Reply" className="rounded-md p-1 hover:bg-raised" onClick={()=>onReply(message)}><Reply size={15}/></button>
      {threadOpen&&<button type="button" title="Open thread" aria-label="Open thread" className="rounded-md p-1 hover:bg-raised" onClick={()=>onThread(message)}><MessageCircleReply size={15}/></button>}
      <div className="relative"><button type="button" aria-expanded={menu} aria-label="More message actions" onClick={()=>setMenu(v=>!v)} className="rounded-md p-1 hover:bg-raised"><MoreHorizontal size={17}/></button>{menu&&<div className="absolute right-0 top-full z-30 flex w-44 flex-col rounded-xl border border-line bg-surface p-1 shadow-xl">
        {editable&&<button className="rounded-md px-2 py-2 text-left text-xs hover:bg-raised" onClick={()=>{setMenu(false);onEdit(message);}}>Edit message</button>}
        {canModerate&&<button className="rounded-md px-2 py-2 text-left text-xs hover:bg-raised" onClick={()=>run(()=>onChange('pin',message,{pinned:!message.pinnedAt}))}>{message.pinnedAt?'Unpin message':'Pin message'}</button>}
        {message.content&&<button className="rounded-md px-2 py-2 text-left text-xs hover:bg-raised" onClick={()=>{navigator.clipboard?.writeText(message.content);setMenu(false);}}>Copy message</button>}
        {(editable||canModerate)&&<button className="rounded-md px-2 py-2 text-left text-xs text-danger hover:bg-raised" onClick={()=>{if(window.confirm('Delete this message for all community members?'))run(()=>onChange('delete',message));}}>Delete message</button>}
      </div>}</div>
    </div>}
  </article>;
}
export default function ChannelChat({channel,permissions,threadId=null,onThread}){
  const {user}=useAuth();const me=user?.id;const client=useQueryClient();const channelId=String(channel.id||channel._id);
  const key=['community','channel-messages',channelId,threadId||'main'];
  const messages=useInfiniteQuery({queryKey:key,initialPageParam:null,queryFn:({pageParam})=>communityRead(`/channels/${channelId}/messages`,{limit:30,before:pageParam,threadId:threadId||undefined}),getNextPageParam:p=>p.hasMore?p.nextCursor:undefined});
  const [text,setText]=useState(''),[media,setMedia]=useState(null),[reply,setReply]=useState(null),[editing,setEditing]=useState(null),[busy,setBusy]=useState(false),[optimistic,setOptimistic]=useState([]),[error,setError]=useState(''),[search,setSearch]=useState(''),[searchOpen,setSearchOpen]=useState(false),[pinsOpen,setPinsOpen]=useState(false);
  const endRef=useRef(null),inputRef=useRef(null);
  const searchResults=useQuery({queryKey:['community','search',channelId,search],queryFn:()=>communityRead(`/channels/${channelId}/search`,{q:search}),enabled:searchOpen&&search.trim().length>=2});
  const pinned=useQuery({queryKey:['community','pins',channelId],queryFn:()=>communityRead(`/channels/${channelId}/pins`),enabled:pinsOpen});
  useEffect(()=>{setText('');setMedia(null);setReply(null);setEditing(null);setOptimistic([]);setSearchOpen(false);},[channelId,threadId]);
  // Socket updates are persisted server events. No poll-to-deliver delay and no duplicate optimistic entries.
  useEffect(()=>subscribeSocialSocket(socket=>{
    if(!socket)return;
    const join=()=>socket.emit('community:join',{channelId},response=>{if(response?.ok===false)setError(response.error);else client.invalidateQueries({queryKey:key});});
    socket.on('connect',join);if(socket.connected)join();
    const changed=({channelId:target,message})=>{
      if(target!==channelId||!message||String(message.threadId||'')!==String(threadId||''))return;
      client.setQueryData(key,old=>mergeCommunityMessage(old,message,Boolean(message.deletedAt)));
      setOptimistic(list=>list.filter(m=>m.clientId!==message.clientId));
    };
    const pin=({channelId:target})=>{if(target===channelId){client.invalidateQueries({queryKey:key});client.invalidateQueries({queryKey:['community','pins',channelId]});}};
    const reactions=({channelId:target,messageId,reactions})=>{if(target===channelId)client.setQueryData(key,old=>old?{...old,pages:old.pages.map(p=>({...p,items:p.items.map(m=>m.id===messageId?{...m,reactions}:m)}))}:old);};
    socket.on('community:message:new',changed);socket.on('community:message:updated',changed);socket.on('community:message:pinned',pin);socket.on('community:message:reactions',reactions);
    return ()=>{socket.off('connect',join);socket.off('community:message:new',changed);socket.off('community:message:updated',changed);socket.off('community:message:pinned',pin);socket.off('community:message:reactions',reactions);socket.emit('community:leave',{channelId});};
  }),[channelId,threadId,client]);
  const pages=messages.data?.pages||[];
  const rows=useMemo(()=>{
    const base=getAllPages(messages.data);
    const unique=new Map();
    for(const m of base)unique.set(m.id,m);
    for(const m of optimistic){if(m.failed||!base.some(x=>x.clientId===m.clientId))unique.set(m.id,m);}
    return [...unique.values()].sort((a,b)=>new Date(a.createdAt).getTime()-new Date(b.createdAt).getTime());
  },[messages.data,optimistic]);
  useEffect(()=>{endRef.current?.scrollIntoView({behavior:'auto',block:'end'});},[channelId,rows.length]);
  const send=async(override=null,retry=null)=>{
    if(busy||!permissions.includes('send_messages'))return;
    const content=override?.content??(editing?text:text.trim());
    const mediaIds=override?.mediaIds??(media?.id?[media.id]:[]);
    const gifUrl=override?.gifUrl;
    if(!content?.trim()&&!mediaIds.length&&!gifUrl)return;
    setBusy(true);setError('');
    try{
      if(editing){await communityPatch(`/channels/${channelId}/messages/${editing.id}`,{content:content.trim()});setEditing(null);setText('');client.invalidateQueries({queryKey:key});return;}
      const clientId=retry?.clientId||crypto.randomUUID();
      const payload={clientId,content:content.trim(),mediaIds,gifUrl,replyTo:reply?.id,threadId:threadId||undefined};
      if(!retry){setOptimistic(v=>[...v,{id:`pending-${clientId}`,clientId,content:payload.content,mediaIds,gifUrl,senderId:me,sender:user,createdAt:new Date().toISOString(),optimistic:true,reactions:[]}]);setText('');setMedia(null);setReply(null);}
      const message=await communityCreate(`/channels/${channelId}/messages`,payload);
      client.setQueryData(key,old=>mergeCommunityMessage(old,message));
      setOptimistic(v=>v.filter(m=>m.clientId!==clientId));
    }catch(err){setError(communityError(err));if(retry)setOptimistic(v=>v.map(m=>m.clientId===retry.clientId?{...m,failed:true}:m));else setOptimistic(v=>v.map(m=>m.optimistic?{...m,failed:true}:m));}
    finally{setBusy(false);}
  };
  const change=async(kind,msg,data)=>{
    if(kind==='retry')return send({content:msg.content,mediaIds:msg.mediaIds,gifUrl:msg.gifUrl},msg);
    if(kind==='react'){const r=await communityPut(`/channels/${channelId}/messages/${msg.id}/reaction`,data);client.setQueryData(key,old=>old?{...old,pages:old.pages.map(p=>({...p,items:p.items.map(m=>m.id===msg.id?{...m,reactions:r.reactions}:m)}))}:old);return;}
    if(kind==='delete'){await communityDelete(`/channels/${channelId}/messages/${msg.id}`);client.invalidateQueries({queryKey:key});return;}
    if(kind==='pin'){await communityCreate(`/channels/${channelId}/messages/${msg.id}/pin`,data);client.invalidateQueries({queryKey:key});return;}
  };
  useEffect(()=>{
    if(!messages.isSuccess)return;
    const timer=setTimeout(()=>{
      communityCreate(`/channels/${channelId}/read`,{}).then(()=>client.invalidateQueries({queryKey:['community','unread']})).catch(()=>{});
    },1200);
    return ()=>clearTimeout(timer);
  },[channelId,messages.isSuccess,messages.dataUpdatedAt,client]);
  const canModerate=permissions.includes('manage_messages');
  const canSend=permissions.includes('send_messages')&&(channel.type!=='announcement'||canModerate);
  return <div className="flex min-h-0 flex-1 flex-col bg-canvas">
    <div className="flex shrink-0 items-center justify-between gap-2 border-b border-line bg-surface px-4 py-3"><div><h2 className="text-sm font-extrabold"># {channel.name}</h2><p className="text-xs text-ink-soft">{channel.topic||'Community text channel'}</p></div><div className="flex gap-1"><button className={smallButton} title="Search channel" onClick={()=>setSearchOpen(v=>!v)}><Search size={17}/></button><button className={smallButton} title="Pinned messages" onClick={()=>setPinsOpen(v=>!v)}><Pin size={17}/></button></div></div>
    {searchOpen&&<div className="max-h-40 overflow-y-auto border-b border-line bg-surface p-3"><label className="flex gap-2"><input className={field} placeholder="Search messages" value={search} onChange={e=>setSearch(e.target.value)}/><button onClick={()=>setSearchOpen(false)} aria-label="Close search"><X size={18}/></button></label>{searchResults.data?.items?.map(m=><button key={m.id} className="block w-full p-2 text-left text-xs hover:bg-raised" onClick={()=>document.getElementById(`community-message-${m.id}`)?.scrollIntoView({behavior:'smooth',block:'center'})}>{m.content?.slice(0,100)}</button>)}</div>}
    {pinsOpen&&<div className="max-h-40 overflow-y-auto border-b border-line bg-surface p-3"><p className="mb-2 text-xs font-bold">Pinned messages</p>{pinned.data?.map(m=><button key={m.id} className="block w-full rounded-lg p-2 text-left text-xs hover:bg-raised" onClick={()=>{document.getElementById(`community-message-${m.id}`)?.scrollIntoView({behavior:'smooth',block:'center'});setPinsOpen(false);}}>{m.content?.slice(0,120)||'Attachment'}</button>)}{pinned.data?.length===0&&<p className="text-xs text-ink-soft">No pinned messages.</p>}</div>}
    <div className="custom-scrollbar min-h-0 flex-1 overflow-y-auto px-2 py-5" aria-label="Channel messages">
      {messages.isLoading?<p role="status" className="p-4 text-sm text-ink-soft"><LoaderCircle className="mr-2 inline size-4 animate-spin"/>Loading messages...</p>:messages.isError?<ErrorNotice error={messages.error}/>:<>
        {messages.hasNextPage&&<div className="mb-4 text-center"><button disabled={messages.isFetchingNextPage} className={smallButton} onClick={()=>messages.fetchNextPage()}>{messages.isFetchingNextPage?'Loading...':'Load older messages'}</button></div>}
        {rows.length?rows.map(m=><ChatBubble key={m.id} message={m} me={me} canModerate={canModerate} onReply={setReply} onEdit={m=>{setEditing(m);setText(m.content||'');setReply(null);}} onChange={change} threadOpen={channel.type==='forum'} onThread={onThread}/>):<p className="p-8 text-center text-sm text-ink-soft">No messages yet. Start the conversation.</p>}
      </>}
      <div ref={endRef}/>
    </div>
    {error&&<div className="border-t border-line px-3 py-2"><ErrorNotice error={error}/></div>}
    {canSend?<ChatComposer text={text} setText={setText} media={media} setMedia={setMedia} reply={reply} cancelReply={()=>setReply(null)} editing={editing} cancelEditing={()=>{setEditing(null);setText('');}} onSubmit={()=>send()} onGif={gif=>send({content:'',mediaIds:gif.mediaId?[gif.mediaId]:[],gifUrl:gif.mediaId?undefined:gif.url})} onQuickEmoji={()=>send({content:'👍'})} busy={busy} mediaPurpose="community" />:<p className="border-t border-line p-4 text-center text-sm text-ink-soft">You can read this channel but do not have permission to post.</p>}
  </div>;
}
