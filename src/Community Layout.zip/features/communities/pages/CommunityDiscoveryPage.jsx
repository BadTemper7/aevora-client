import { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronRight, Compass, Copy, Headphones, LoaderCircle, Plus, Search, UsersRound, X } from 'lucide-react';
import { communityRead,communityCreate,communityError,communityFile } from '../api/communityApi';
import { read } from '../../social/api/socialApi';
import MediaPicker from '../../social/components/MediaPicker';
import { useVoiceSession } from '../hooks/useVoiceSession';
import { field,smallButton,ErrorNotice,Loading } from '../../social/components/SocialUI';
const groups=['All','Gaming','Technology','Entertainment','Education','General'];
const initial={name:'',slug:'',description:'',visibility:'public',category:'General',rules:'',requireApproval:false,iconId:'',bannerId:''};
function PreviewCard({community,onJoin,pending}){
  return <div className="flex flex-col overflow-hidden rounded-2xl border border-line bg-surface shadow-sm">
    <div className="h-24 bg-gradient-to-br from-brand-soft via-raised to-canvas">{community.bannerId&&<img src={communityFile(community.bannerId)} className="size-full object-cover" alt="" loading="lazy"/>}</div>
    <div className="flex flex-1 flex-col gap-2 px-4 pb-4"><div className="-mt-6 grid size-12 place-items-center overflow-hidden rounded-xl border-4 border-surface bg-brand-soft text-xl font-extrabold text-brand-ink">{community.iconId?<img src={communityFile(community.iconId,true)} alt="" className="size-full object-cover"/>:community.name[0]?.toUpperCase()}</div>
      <div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="truncate text-sm font-extrabold">{community.name}</p><p className="text-xs text-ink-soft">{community.category} · {community.memberCount||0} members</p></div><span className="rounded-md bg-raised px-2 py-1 text-[10px] font-semibold capitalize">{community.visibility}</span></div>
      <p className="mb-2 line-clamp-2 min-h-9 text-sm text-ink-soft">{community.description||'A space to connect, collaborate, and share.'}</p>
      <div className="mt-auto flex items-center gap-2"><Link to={`/communities/${community.id}`} className="flex-1 rounded-lg border border-line py-2 text-center text-xs font-bold hover:bg-raised">View community</Link>{onJoin&&<button disabled={pending} onClick={()=>onJoin(community)} className="flex-1 rounded-lg bg-brand px-2 py-2 text-xs font-bold text-on-brand disabled:opacity-60">{pending?'Joining...':community.requireApproval?'Request access':'Join'}</button>}</div>
    </div>
  </div>;
}
export default function CommunityDiscoveryPage(){
  const client=useQueryClient(),navigate=useNavigate();const voice=useVoiceSession();
  const [q,setQ]=useState(''),[queryTerm,setQueryTerm]=useState(''),[category,setCategory]=useState('All');
  const [creating,setCreating]=useState(false),[form,setForm]=useState(initial),[selectedFriends,setSelectedFriends]=useState([]);
  const [acceptRules,setAcceptRules]=useState(false),[busy,setBusy]=useState(''),[error,setError]=useState(''),[success,setSuccess]=useState('');
  useEffect(()=>{const t=setTimeout(()=>setQueryTerm(q),260);return ()=>clearTimeout(t);},[q]);
  const mine=useQuery({queryKey:['communities','mine'],queryFn:()=>communityRead('/communities')});
  const discover=useQuery({queryKey:['communities','discover',queryTerm,category],queryFn:()=>communityRead('/communities/discover',{q:queryTerm,category})});
  const invites=useQuery({queryKey:['communities','invites'],queryFn:()=>communityRead('/communities/invitations')});
  const friends=useQuery({queryKey:['friends','communities'],queryFn:()=>read('/friends',{tab:'friends'}),enabled:creating});
  const quick=useQuery({queryKey:['communities','quick'],queryFn:()=>communityRead('/voice/quick')});
  const refresh=()=>{client.invalidateQueries({queryKey:['communities']});};
  const join=async community=>{
    setBusy(`join-${community.id}`);setError('');setSuccess('');
    try{const r=await communityCreate(`/communities/${community.id}/join`,{rulesAccepted:acceptRules});refresh();if(r.status==='active')navigate(`/communities/${community.id}`);else setSuccess('Your request to join is pending approval.');}
    catch(err){setError(communityError(err));}finally{setBusy('');}
  };
  const create=async event=>{event.preventDefault();setBusy('create');setError('');try{
    const payload={...form};if(!payload.slug)delete payload.slug;if(!payload.iconId)delete payload.iconId;if(!payload.bannerId)delete payload.bannerId;
    const c=await communityCreate('/communities',payload);
    for(const id of selectedFriends){try{await communityCreate(`/communities/${c.id}/invitations`,{userId:id});}catch(err){console.warn('Friend invitation failed:',err.message);}}
    refresh();setCreating(false);navigate(`/communities/${c.id}`);
  }catch(err){setError(communityError(err));}finally{setBusy('');}};
  const respond=async(id,action,rules)=>{setBusy(id);setError('');try{const r=await communityCreate(`/communities/invitations/${id}/respond`,{action,rulesAccepted:rules});refresh();if(r.status==='active')setSuccess('Invitation accepted. Your community is in My Communities.');else if(r.status==='pending')setSuccess('Membership approval is pending.');}catch(err){setError(communityError(err));}finally{setBusy('');}};
  const createQuick=async friendId=>{setBusy('quick');setError('');try{const r=await communityCreate('/voice/quick',{friendIds:[friendId]});await voice.join(r.roomId,{quick:true});refresh();}catch(err){setError(communityError(err));}finally{setBusy('');}};
  return <div className="w-full overflow-y-auto px-3 py-5 pb-28 sm:px-6 lg:px-8">
    <div className="mx-auto max-w-[1280px] space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4"><div><h1 className="text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">Communities</h1><p className="mt-1 text-sm text-ink-soft">Find spaces to talk, share, play, and create together.</p></div><button type="button" onClick={()=>{setCreating(true);setError('');}} className="inline-flex items-center gap-2 rounded-xl bg-brand px-4 py-3 text-sm font-bold text-on-brand"><Plus size={18}/>Create community</button></div>
      {error&&<ErrorNotice error={error}/ >}{success&&<p role="status" className="rounded-lg border border-success/30 bg-success/10 p-3 text-sm text-success">{success}</p>}
      {invites.data?.length>0&&<section className="space-y-3 rounded-2xl border border-brand/25 bg-brand-soft/20 p-4"><h2 className="font-extrabold">Community invitations ({invites.data.length})</h2>{invites.data.map(i=><InvitationRow key={i.id} invitation={i} busy={busy===i.id} onRespond={respond}/>)}</section>}
      <section><h2 className="mb-4 text-lg font-extrabold">Your communities</h2>{mine.isLoading?<Loading label="Loading your communities..."/>:mine.isError?<ErrorNotice error={mine.error}/>:mine.data?.length?<div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{mine.data.map(c=><PreviewCard key={c.id} community={c}/>)}</div>:<div className="rounded-xl border border-dashed border-line p-6 text-sm text-ink-soft">You have not joined a community yet. Explore public communities or start your own.</div>}</section>
      <section className="space-y-4"><div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><h2 className="text-lg font-extrabold">Discover communities</h2><label className="relative min-w-0 sm:w-80"><Search size={16} className="absolute left-3 top-3 text-ink-faint"/><input className={`${field} !pl-9`} value={q} onChange={e=>setQ(e.target.value)} placeholder="Search communities" aria-label="Search public communities"/></label></div>
        <div className="flex flex-wrap gap-2">{groups.map(g=><button type="button" key={g} aria-pressed={category===g} onClick={()=>setCategory(g)} className={`rounded-full px-3 py-1.5 text-xs font-bold ${category===g?'bg-brand text-on-brand':'border border-line bg-surface text-ink-soft'}`}>{g}</button>)}</div>
        <label className="flex items-center gap-2 text-xs text-ink-soft"><input type="checkbox" checked={acceptRules} onChange={e=>setAcceptRules(e.target.checked)}/>I agree to review and follow each community's rules when joining.</label>
        {discover.isLoading?<Loading label="Searching communities..."/>:discover.isError?<ErrorNotice error={discover.error}/>:discover.data?.items?.length?<div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{discover.data.items.map(c=><PreviewCard key={c.id} community={c} onJoin={!mine.data?.some(m=>m.id===c.id)?join:null} pending={busy===`join-${c.id}`}/>)}</div>:<p className="rounded-xl border border-dashed border-line p-6 text-sm text-ink-soft">No matching public communities.</p>}
      </section>
      <section className="space-y-3"><h2 className="text-lg font-extrabold">Quick voice rooms with friends</h2><p className="text-sm text-ink-soft">Start a temporary voice session separate from permanent communities.</p><div className="flex flex-wrap gap-2">{quick.data?.map(r=><button key={r.roomId} className={smallButton} onClick={()=>voice.join(r.roomId,{quick:true})}>Join room from {new Date(r.createdAt).toLocaleString()}</button>)}<QuickFriendRoom onCreate={createQuick} busy={busy==='quick'}/></div>{voice.error&&<ErrorNotice error={voice.error}/>}</section>
    </div>
    {creating&&<div role="presentation" className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3" onMouseDown={e=>{if(e.target===e.currentTarget)setCreating(false);}}><form onSubmit={create} role="dialog" aria-modal="true" aria-label="Create community" className="max-h-[90dvh] w-full max-w-xl space-y-4 overflow-y-auto rounded-2xl border border-line bg-surface p-5 shadow-2xl">
      <div className="flex items-center justify-between"><h2 className="text-xl font-extrabold">Create a community</h2><button type="button" title="Close" onClick={()=>setCreating(false)}><X size={20}/></button></div>
      <label className="block text-sm font-bold">Community name<input required className={`mt-1 ${field}`} maxLength={80} value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))}/></label>
      <label className="block text-sm font-bold">Unique identifier<input className={`mt-1 ${field}`} pattern="[a-z0-9]([a-z0-9-]{1,46})[a-z0-9]" placeholder="my-community" value={form.slug} onChange={e=>setForm(f=>({...f,slug:e.target.value.toLowerCase()}))}/><span className="mt-1 block text-xs font-normal text-ink-soft">Leave blank to generate from the name. Letters, numbers and hyphens.</span></label>
      <label className="block text-sm font-bold">Description<textarea className={`mt-1 ${field}`} rows={3} maxLength={2000} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}/></label>
      <div className="grid gap-3 sm:grid-cols-2"><label className="block text-sm font-bold">Visibility<select className={`mt-1 ${field}`} value={form.visibility} onChange={e=>setForm(f=>({...f,visibility:e.target.value}))}><option value="public">Public</option><option value="private">Private (request approval)</option><option value="invite">Invite only</option></select></label><label className="block text-sm font-bold">Category<select className={`mt-1 ${field}`} value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))}>{groups.filter(g=>g!=='All').map(g=><option key={g}>{g}</option>)}</select></label></div>
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.requireApproval} onChange={e=>setForm(f=>({...f,requireApproval:e.target.checked}))}/>Require approval for new members</label>
      <label className="block text-sm font-bold">Community rules<textarea className={`mt-1 ${field}`} rows={3} maxLength={6000} placeholder="Community guidelines" value={form.rules} onChange={e=>setForm(f=>({...f,rules:e.target.value}))}/></label>
      <details className="rounded-xl border border-line p-3"><summary className="cursor-pointer text-sm font-bold">Community icon and banner</summary><div className="mt-3 space-y-3"><MediaPicker purpose="community" accept="image/*" label="Upload icon" onReady={m=>setForm(f=>({...f,iconId:m?.id||''}))}/><MediaPicker purpose="community" accept="image/*" label="Upload banner" onReady={m=>setForm(f=>({...f,bannerId:m?.id||''}))}/></div></details>
      <details className="rounded-xl border border-line p-3"><summary className="cursor-pointer text-sm font-bold">Invite friends during setup</summary><div className="mt-2 max-h-36 space-y-1 overflow-y-auto">{friends.isLoading?'Loading friends...':(friends.data||[]).length?friends.data.map(r=><label key={r.user?.id} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={selectedFriends.includes(r.user?.id)} onChange={e=>setSelectedFriends(v=>e.target.checked?[...v,r.user.id]:v.filter(x=>x!==r.user.id))}/>@{r.user?.username}</label>):'No friends to invite yet.'}</div></details>
      {error&&<ErrorNotice error={error}/>}<button disabled={busy==='create'} type="submit" className="flex w-full items-center justify-center gap-2 rounded-xl bg-brand px-4 py-3 text-sm font-bold text-on-brand disabled:opacity-60">{busy==='create'?<><LoaderCircle size={17} className="animate-spin"/>Creating community...</>:<><Plus size={17}/>Create community</>}</button>
    </form></div>}
  </div>;
}
function InvitationRow({invitation,busy,onRespond}){
  const [rulesAccepted,setRulesAccepted]=useState(false);
  return <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl bg-surface p-3"><div><p className="text-sm font-bold">{invitation.community.name}</p><p className="text-xs text-ink-soft">Invited to join · {invitation.community.visibility}</p>{invitation.community.rules&&<details className="max-w-lg text-xs"><summary className="cursor-pointer">Read community rules</summary><p className="whitespace-pre-wrap">{invitation.community.rules}</p><label className="flex items-center gap-2"><input type="checkbox" checked={rulesAccepted} onChange={e=>setRulesAccepted(e.target.checked)}/>I agree to the rules</label></details>}</div><div className="flex gap-2"><button className={smallButton} disabled={busy||Boolean(invitation.community.rules&&!rulesAccepted)} onClick={()=>onRespond(invitation.id,'accept',rulesAccepted)}>Accept</button><button className={smallButton} disabled={busy} onClick={()=>onRespond(invitation.id,'decline',false)}>Decline</button></div></div>;
}
function QuickFriendRoom({onCreate,busy}){
  const [open,setOpen]=useState(false);const [search,setSearch]=useState('');
  const friends=useQuery({queryKey:['friends','quickvoice'],queryFn:()=>read('/friends',{tab:'friends'}),enabled:open});
  return <div className="relative"><button className="inline-flex items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2 text-sm font-bold" onClick={()=>setOpen(v=>!v)}><Headphones size={17}/>Start with a friend</button>{open&&<div className="absolute left-0 top-full z-30 mt-2 w-72 rounded-xl border border-line bg-surface p-3 shadow-xl"><input className={field} placeholder="Search your friends" value={search} onChange={e=>setSearch(e.target.value)}/><div className="mt-2 max-h-40 overflow-y-auto">{(friends.data||[]).filter(r=>r.user?.username?.toLowerCase().includes(search.toLowerCase())).map(r=><button key={r.user.id} disabled={busy} className="block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-raised" onClick={()=>{onCreate(r.user.id);setOpen(false);}}>Start with @{r.user.username}</button>)}</div></div>}</div>;
}
