import { useEffect, useMemo, useState } from 'react';
import { useQuery,useQueryClient } from '@tanstack/react-query';
import { Link,useNavigate,useParams,useSearchParams } from 'react-router-dom';
import { CalendarDays, ChevronDown, Compass, Crown, Hash, Headphones, LoaderCircle, LockKeyhole, Menu, Megaphone, MessageCircle, MonitorUp, Plus, Radio, Search, Settings, Shield, UserPlus, Users, Video, X } from 'lucide-react';
import { getSocialSocket,subscribeSocialSocket } from '../../../services/socket/socketClient';
import { communityRead,communityCreate,communityError,communityFile } from '../api/communityApi';
import { useVoiceSession } from '../hooks/useVoiceSession';
import { ErrorNotice,Loading,field,smallButton } from '../../social/components/SocialUI';
import { useAuth } from '../../auth/hooks/useAuth';
import ChannelChat from '../components/ChannelChat';
import { ForumPanel,PollPanel,EventsPanel,InvitesPanel } from '../components/CommunityPanels';
import CommunitySettingsPanel from '../components/CommunitySettingsPanel';
import { MessageCircleReply } from 'lucide-react';
const icons={text:Hash,announcement:Megaphone,voice:Headphones,video:Video,forum:MessageCircleReply,stage:Radio};
function VoicePeople({channelId}){
  const q=useQuery({queryKey:['community','participants',channelId],queryFn:()=>communityRead(`/channels/${channelId}/voice/participants`),refetchInterval:15000,staleTime:6000});
  return <div className="ml-8 space-y-0.5" aria-label="Voice participants">{q.data?.items?.map(p=><div key={p.userId} className="flex items-center gap-2 truncate text-xs text-ink-soft"><span className="size-1.5 shrink-0 rounded-full bg-success"/>{p.name}</div>)}</div>;
}
function ChannelButton({channel,communityId,selected,onNavigate,onJoin,joining,unread}){
  const Icon=icons[channel.type]||Hash;const voice=['voice','video','stage'].includes(channel.type);
  return <div className="space-y-1"><div className={`flex items-center gap-1 rounded-lg ${selected?'bg-brand-soft text-brand-ink':'text-ink-soft hover:bg-raised hover:text-ink'}`}>
    <button type="button" onClick={()=>onNavigate(channel)} className="flex min-w-0 flex-1 items-center gap-2 px-3 py-2 text-left text-sm font-semibold" aria-current={selected?'page':undefined}><Icon size={17} className="shrink-0"/><span className="truncate">{channel.name}</span>{unread?.count>0&&<span aria-label={`${unread.count} unread messages`} className="ml-auto rounded-full bg-brand px-1.5 py-0.5 text-[10px] text-on-brand">{unread.count}{unread.mentions>0?` · @${unread.mentions}`:''}</span>}</button>
    {voice&&<button type="button" title={`Join ${channel.name} live`} aria-label={`Join voice channel ${channel.name}`} onClick={()=>onJoin(channel)} disabled={joining} className="rounded-lg px-2 py-2 hover:bg-raised disabled:opacity-60">{joining?<LoaderCircle size={13} className="animate-spin"/>:<Plus size={15}/>}</button>}
  </div>{voice&&<VoicePeople channelId={channel.id}/>}</div>;
}
function CommunityChannels({community,selected,onNavigate,onJoin,joining,view,setView}){
  const unread=useQuery({queryKey:['community','unread',community.id],queryFn:()=>communityRead(`/communities/${community.id}/unread`),refetchInterval:30000,staleTime:10000});
  const categories=community.categories||[];const all=community.channels||[];
  const groups=[...categories.map(c=>({id:c.id,name:c.name,items:all.filter(ch=>String(ch.categoryId)===String(c.id))})),{id:'none',name:'OTHER CHANNELS',items:all.filter(ch=>!ch.categoryId)}].filter(g=>g.items.length>0);
  return <nav aria-label="Community channels" className="space-y-4 overflow-y-auto px-3 pb-6">
    {groups.map(g=><section key={g.id}><p className="mb-2 px-2 text-[11px] font-extrabold tracking-wide text-ink-faint">{g.name}</p><div className="space-y-1">{g.items.map(ch=><ChannelButton key={ch.id} channel={ch} communityId={community.id} selected={selected?.id===ch.id&&view==='channel'} onNavigate={onNavigate} onJoin={onJoin} joining={joining} unread={unread.data?.[ch.id]}/>)}</div></section>)}
    <section className="space-y-1 border-t border-line pt-3"><button onClick={()=>setView('events')} className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm font-semibold ${view==='events'?'bg-brand-soft text-brand-ink':'text-ink-soft hover:bg-raised'}`}><CalendarDays size={17}/> Events</button><button onClick={()=>setView('invites')} className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm font-semibold ${view==='invites'?'bg-brand-soft text-brand-ink':'text-ink-soft hover:bg-raised'}`}><UserPlus size={17}/> Invitations</button><button onClick={()=>setView('settings')} className={`flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm font-semibold ${view==='settings'?'bg-brand-soft text-brand-ink':'text-ink-soft hover:bg-raised'}`}><Settings size={17}/> Settings</button></section>
  </nav>;
}
function StageControls({channel,community,joined,voice}) {
  const {user}=useAuth();
  const cache=useQueryClient();
  const [topic,setTopic]=useState('');
  const [error,setError]=useState('');
  const [busy,setBusy]=useState(false);
  const canModerate=community.permissions?.includes('mute_members');
  const canManage=community.permissions?.includes('manage_events');
  const query=useQuery({queryKey:['community','stage',channel.id],queryFn:()=>communityRead(`/channels/${channel.id}/stage`),refetchInterval:12000});
  const stage=query.data;
  useEffect(()=>{if(stage?.topic)setTopic(stage.topic);},[stage?.topic]);
  const apply=async(path,data)=>{
    setError('');setBusy(true);
    try{await communityCreate(path,data);await cache.invalidateQueries({queryKey:['community','stage',channel.id]});}
    catch(err){setError(communityError(err));}finally{setBusy(false);}
  };
  const refresh=()=>{if(joined)voice.join(channel.id);};
  const myHand=stage?.raisedHands?.includes(user?.id);
  const mySpeaker=stage?.speakers?.includes(user?.id);
  const memberName=id=>community.members?.find(m=>m.userId===id)?.user?.username||id;
  return <section className="w-full max-w-xl space-y-3 rounded-xl border border-line bg-surface p-4 text-left">
    <div className="flex items-center justify-between"><h3 className="text-sm font-bold">Stage controls</h3><span className="text-xs text-ink-soft">{stage?.active?'Live stage':'Stage not started'}</span></div>
    {query.isError&&<ErrorNotice error={query.error}/ >}
    {stage?.topic&&<p className="text-sm">{stage.topic}</p>}
    <p className="text-xs text-ink-soft">Audience members can listen. Only approved speakers can turn on their microphones.</p>
    {!canModerate&&<button className={smallButton} disabled={busy} onClick={()=>apply(`/channels/${channel.id}/stage/hand`,{raised:!myHand})}>{myHand?'Lower hand':'Raise hand to speak'}</button>}
    {mySpeaker&&joined&&<button className={smallButton} disabled={voice.busy} onClick={refresh}>Reconnect to enable speaking</button>}
    {canManage&&<div className="flex flex-wrap gap-2"><input className={`${field} min-w-0 flex-1`} value={topic} onChange={e=>setTopic(e.target.value)} maxLength={140} placeholder="Stage topic"/><button className={smallButton} disabled={busy} onClick={()=>apply(`/channels/${channel.id}/stage`,{topic,active:!stage?.active})}>{stage?.active?'End stage':'Start stage'}</button><button className={smallButton} disabled={busy} onClick={()=>apply(`/channels/${channel.id}/stage`,{topic})}>Save topic</button></div>}
    {canModerate&&<><p className="text-xs font-bold">Raised hands</p>{stage?.raisedHands?.length?stage.raisedHands.map(id=><div key={id} className="flex items-center justify-between gap-2 text-xs"><span>@{memberName(id)}</span><button className={smallButton} disabled={busy} onClick={()=>apply(`/channels/${channel.id}/stage/speaker`,{userId:id,allowed:true})}>Approve speaker</button></div>):<p className="text-xs text-ink-soft">No hands raised.</p>}<p className="text-xs font-bold">Approved speakers</p>{stage?.speakers?.map(id=><div key={id} className="flex items-center justify-between gap-2 text-xs"><span>@{memberName(id)}</span><button className={smallButton} disabled={busy} onClick={()=>apply(`/channels/${channel.id}/stage/speaker`,{userId:id,allowed:false})}>Move to audience</button></div>)}</>}
    {error&&<ErrorNotice error={error}/ >}
  </section>;
}
function VoiceChannel({channel,voice,community}){
  const joined=voice.session?.channelId===channel.id;
  const people=useQuery({queryKey:['community','participants',channel.id],queryFn:()=>communityRead(`/channels/${channel.id}/voice/participants`),refetchInterval:8000,staleTime:4000});
  const [moderationError,setModerationError]=useState('');
  const canMute=community.permissions?.includes('mute_members');
  const mute=async userId=>{setModerationError('');try{await communityCreate(`/channels/${channel.id}/voice/mute/${userId}`,{minutes:10});await people.refetch();}catch(e){setModerationError(communityError(e));}};
  return <div className="flex flex-1 flex-col items-center gap-4 overflow-y-auto p-5 text-center"><div className="grid size-20 shrink-0 place-items-center rounded-2xl bg-brand-soft text-brand-ink">{channel.type==='video'?<Video size={38}/>:channel.type==='stage'?<Radio size={38}/>:<Headphones size={38}/>}</div><h2 className="text-2xl font-extrabold">{channel.name}</h2><p className="max-w-lg text-sm text-ink-soft">{channel.topic||'Join a live conversation, turn on your camera, or share your screen with permission.'}</p><p className="text-sm text-ink-soft">{people.data?.items?.length||0} connected</p>{people.data?.items?.length>0&&<div className="flex flex-wrap justify-center gap-2">{people.data.items.map(p=><span className="flex items-center gap-2 rounded-lg border border-line bg-surface px-3 py-2 text-sm" key={p.userId}>{p.name}{canMute&&p.userId!==community.ownerId&&<button className="text-xs text-danger" onClick={()=>mute(p.userId)} title="Mute participant for 10 minutes">Mute</button>}</span>)}</div>}
    {joined?<button className="rounded-xl bg-brand px-5 py-3 text-sm font-bold text-on-brand" onClick={()=>voice.setExpanded(true)}>Open voice session</button>:<button className="rounded-xl bg-brand px-5 py-3 text-sm font-bold text-on-brand disabled:opacity-50" disabled={voice.busy} onClick={()=>voice.join(channel.id)}>{voice.busy?'Connecting...':'Join channel'}</button>}
    {channel.type==='stage'&&<StageControls channel={channel} community={community} joined={joined} voice={voice}/ >}
    {voice.error&&<ErrorNotice error={voice.error}/ >}{moderationError&&<ErrorNotice error={moderationError}/ >}<p className="max-w-md text-xs text-ink-faint">Voice requires a configured LiveKit server and browser microphone permission. Screen sharing always opens the browser's selection prompt.</p>
  </div>;
}
function MemberList({community,onClose}){
  const ids=(community.members||[]).map(m=>m.userId).slice(0,100).join(',');
  const presence=useQuery({queryKey:['community','presence',community.id,ids],queryFn:()=>communityRead(`/communities/${community.id}/presence`,{ids}),enabled:Boolean(ids),refetchInterval:30000,staleTime:10000});
  const [search,setSearch]=useState(''),[reporting,setReporting]=useState(null),[reason,setReason]=useState(''),[details,setDetails]=useState(''),[feedback,setFeedback]=useState('');
  const people=(community.members||[]).filter(m=>(m.user?.username||m.user?.name||'').toLowerCase().includes(search.toLowerCase()));
  const report=async()=>{try{await communityCreate(`/communities/${community.id}/reports`,{targetType:'member',targetId:reporting.userId,reason,details});setFeedback('Report submitted to community moderators.');setReporting(null);setReason('');setDetails('');}catch(e){setFeedback(communityError(e));}};
  return <aside className="flex h-full w-64 shrink-0 flex-col overflow-hidden border-l border-line bg-surface"><div className="flex items-center justify-between border-b border-line p-3"><h3 className="text-sm font-extrabold">Members · {community.memberCount}</h3><button onClick={onClose} aria-label="Close member list"><X size={18}/></button></div><div className="p-3"><input className={`${field} !py-2`} placeholder="Find a member" aria-label="Search members" value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="custom-scrollbar flex-1 space-y-1 overflow-y-auto px-2 pb-4">{people.map(m=><div key={m.userId} className="flex items-center gap-2 rounded-lg px-2 py-2 hover:bg-raised"><Link to={m.user?.username?`/u/${m.user.username}`:'#'} className="flex min-w-0 flex-1 items-center gap-2"><div className="grid size-8 shrink-0 place-items-center overflow-hidden rounded-full bg-brand-soft text-xs font-bold text-brand-ink">{m.user?.image?<img className="size-full object-cover" src={m.user.image} alt=""/>:(m.nickname||m.user?.name||'?').slice(0,1)}</div><div className="min-w-0"><p className="truncate text-xs font-bold">{m.nickname||m.user?.name||m.user?.username||'Member'}</p><p className="truncate text-[10px] capitalize text-ink-faint">{m.role}{presence.data?.[m.userId]?.visible?` · ${presence.data[m.userId].online?'Online':'Offline'}`:''}</p></div></Link>{m.role==='owner'&&<Crown size={15} className="text-brand-ink"/>}<button type="button" title="Report member" onClick={()=>setReporting(m)} className="text-xs text-ink-faint hover:text-danger"><Shield size={14}/></button></div>)}</div>
    {feedback&&<p className="px-3 py-2 text-xs text-ink-soft">{feedback}</p>}
    {reporting&&<div className="border-t border-line p-3"><p className="mb-2 text-xs font-bold">Report @{reporting.user?.username}</p><select className={field} value={reason} onChange={e=>setReason(e.target.value)}><option value="">Select reason</option>{['Harassment','Spam','Scam','Hate or abuse','Other'].map(r=><option key={r}>{r}</option>)}</select><textarea className={`mt-2 ${field}`} value={details} onChange={e=>setDetails(e.target.value)} placeholder="Optional details"/><div className="mt-2 flex gap-2"><button className={smallButton} disabled={!reason} onClick={report}>Submit</button><button className={smallButton} onClick={()=>setReporting(null)}>Cancel</button></div></div>}
  </aside>;
}
export default function CommunityPage(){
  const {id,channelId}=useParams(),navigate=useNavigate(),cache=useQueryClient(),voice=useVoiceSession();const {user}=useAuth();
  const [params,setParams]=useSearchParams();const view=params.get('view')||'channel';
  const [sidebar,setSidebar]=useState(false),[membersOpen,setMembersOpen]=useState(true),[mobileMembersOpen,setMobileMembersOpen]=useState(false),[joinRules,setJoinRules]=useState(false),[error,setError]=useState(''),[joinBusy,setJoinBusy]=useState(false);
  const myCommunities=useQuery({queryKey:['communities','mine'],queryFn:()=>communityRead('/communities')});
  const q=useQuery({queryKey:['community','detail',id],queryFn:()=>communityRead(`/communities/${id}`),retry:false});
  const community=q.data;
  const selected=(community?.channels||[]).find(c=>c.id===channelId)||(community?.channels||[]).find(c=>c.type==='text');
  const setView=next=>{setParams(next==='channel'?{}:{view:next});setSidebar(false);};
  const select=channel=>{setSidebar(false);navigate(`/communities/${id}/${channel.id}`);};
  const join=async()=>{setJoinBusy(true);setError('');try{const r=await communityCreate(`/communities/${id}/join`,{rulesAccepted:joinRules});cache.invalidateQueries({queryKey:['community','detail',id]});cache.invalidateQueries({queryKey:['communities','mine']});if(r.status==='pending')setError('Your membership request is waiting for approval.');}catch(err){setError(communityError(err));}finally{setJoinBusy(false);}};
  useEffect(()=>{if(community?.isMember&&(!channelId||!community.channels?.some(c=>c.id===channelId))&&community.channels?.length)navigate(`/communities/${id}/${community.channels[0].id}`,{replace:true});},[community?.isMember,community?.channels,channelId,id,navigate]);
  useEffect(()=>subscribeSocialSocket(socket=>{
    if(!socket)return;
    const joinRoom=()=>socket.emit('community:join',{communityId:id});
    socket.on('connect',joinRoom);if(socket.connected)joinRoom();
    const onChange=payload=>{if(payload?.communityId===id){cache.invalidateQueries({queryKey:['community','detail',id]});cache.invalidateQueries({queryKey:['communities','mine']});}};
    const onVoice=payload=>{if(payload?.channelId)cache.invalidateQueries({queryKey:['community','participants',payload.channelId]});};
    const onRemove=payload=>{if(payload?.communityId===id){voice.leave();navigate('/communities');}};
    socket.on('community:channels',onChange);socket.on('community:updated',onChange);socket.on('community:member',onChange);socket.on('community:event',onChange);socket.on('community:voice:presence',onVoice);socket.on('community:removed',onRemove);
    return ()=>{socket.off('connect',joinRoom);socket.off('community:channels',onChange);socket.off('community:updated',onChange);socket.off('community:member',onChange);socket.off('community:event',onChange);socket.off('community:voice:presence',onVoice);socket.off('community:removed',onRemove);socket.emit('community:leave',{communityId:id});};
  }),[id,cache,navigate,voice.leave]);
  if(q.isLoading)return <div className="w-full p-6"><Loading label="Loading community..."/></div>;
  if(q.isError)return <div className="w-full p-6"><ErrorNotice error={q.error}/><Link to="/communities" className="mt-3 inline-block text-sm text-brand-ink">← Back to communities</Link></div>;
  if(!community?.isMember)return <div className="mx-auto w-full max-w-3xl overflow-y-auto p-6"><Link to="/communities" className="text-sm text-brand-ink">← Discover communities</Link><div className="mt-5 space-y-4 rounded-2xl border border-line bg-surface p-6"><h1 className="text-3xl font-extrabold">{community.name}</h1><p className="text-sm text-ink-soft">{community.description}</p><p className="text-xs text-ink-soft">{community.category} · {community.memberCount} members · {community.visibility}</p>{community.rules&&<div className="rounded-xl bg-raised p-4"><h2 className="mb-2 font-bold">Community rules</h2><p className="whitespace-pre-wrap text-sm">{community.rules}</p><label className="mt-3 flex items-center gap-2 text-sm"><input type="checkbox" checked={joinRules} onChange={e=>setJoinRules(e.target.checked)}/>I agree to the community rules</label></div>}{error&&<ErrorNotice error={error}/>}<button disabled={joinBusy||community.visibility==='invite'||Boolean(community.rules&&!joinRules)} onClick={join} className="rounded-xl bg-brand px-5 py-3 text-sm font-bold text-on-brand disabled:opacity-40">{community.visibility==='invite'?'Invitation required':joinBusy?'Sending...':community.visibility==='private'||community.requireApproval?'Request to join':'Join community'}</button></div></div>;
  const hydrated={...community,currentUserId:user?.id};
  return <div className="flex h-full min-w-0 flex-1 overflow-hidden">
    <nav aria-label="My communities" className="custom-scrollbar flex w-14 shrink-0 flex-col items-center gap-3 overflow-y-auto border-r border-line bg-raised p-2 sm:w-16"><Link to="/communities" title="Discover communities" className="grid size-10 place-items-center rounded-xl bg-surface text-ink-soft"><Compass size={19}/></Link><div className="h-px w-7 bg-line"/>{myCommunities.data?.map(c=><Link to={`/communities/${c.id}`} key={c.id} title={c.name} className={`grid size-10 shrink-0 place-items-center overflow-hidden rounded-2xl text-sm font-extrabold ${c.id===id?'bg-brand text-on-brand':'bg-brand-soft text-brand-ink'}`}>{c.iconId?<img src={communityFile(c.iconId,true)} className="size-full object-cover" alt={c.name}/>:c.name.slice(0,2).toUpperCase()}</Link>)}<Link to="/communities" title="Create or find a community" className="grid size-10 place-items-center rounded-xl border border-dashed border-line-strong text-brand-ink"><Plus size={19}/></Link></nav>
    {sidebar&&<button aria-label="Close channel sidebar" className="fixed inset-0 z-20 bg-black/40 md:hidden" onClick={()=>setSidebar(false)}/>}
    <aside className={`${sidebar?'fixed bottom-0 left-14 top-14 z-30 shadow-xl sm:left-16':'hidden'} w-60 shrink-0 border-r border-line bg-surface md:flex md:flex-col`}>
      <div className="flex min-h-16 items-center justify-between gap-2 border-b border-line px-4"><p className="min-w-0 truncate text-sm font-extrabold">{community.name}</p><button title="Community settings" className="text-ink-soft" onClick={()=>setView('settings')}><Settings size={17}/></button></div>
      <CommunityChannels community={community} selected={selected} onNavigate={select} onJoin={ch=>voice.join(ch.id)} joining={voice.busy} view={view} setView={setView}/>
    </aside>
    <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
      <div className="flex shrink-0 items-center justify-between gap-2 border-b border-line bg-surface px-3 py-2 md:px-5"><div className="flex items-center gap-2"><button className="md:hidden" aria-label="Open channel list" onClick={()=>setSidebar(true)}><Menu size={20}/></button><p className="min-w-0 truncate text-sm font-bold">{view==='channel'?(selected?.name||community.name):view==='events'?'Events':view==='invites'?'Invitations':'Settings'}</p></div><><button title="Show or hide member list" className={`${smallButton} hidden lg:inline-flex`} onClick={()=>setMembersOpen(v=>!v)}><Users size={17}/><span className="ml-1 hidden sm:inline">{community.memberCount}</span></button><button title="Open member list" className={`${smallButton} lg:hidden`} onClick={()=>setMobileMembersOpen(true)}><Users size={17}/></button></></div>
      {view==='events'?<EventsPanel community={community} permissions={community.permissions}/>:view==='invites'?<InvitesPanel community={community} permissions={community.permissions}/>:view==='settings'?<CommunitySettingsPanel key={community.id} community={hydrated} permissions={community.permissions}/>:!selected?<div className="p-6 text-sm text-ink-soft">No accessible channels. Ask a moderator to create one.</div>:selected.type==='forum'?<ForumPanel key={selected.id} channel={selected} permissions={community.permissions}/>:['voice','video','stage'].includes(selected.type)?<VoiceChannel key={selected.id} channel={selected} community={community} voice={voice}/>:<><ChannelChat key={selected.id} channel={selected} permissions={community.permissions}/><div className="max-h-64 overflow-y-auto"><PollPanel channel={selected} permissions={community.permissions}/></div></>}
    </div>
    {membersOpen&&<div className="hidden lg:flex"><MemberList community={community} onClose={()=>setMembersOpen(false)}/></div>}
    {mobileMembersOpen&&<><button aria-label="Close member list" className="fixed inset-0 z-40 bg-black/40 lg:hidden" onClick={()=>setMobileMembersOpen(false)}/><div className="fixed inset-y-0 right-0 z-50 flex h-dvh max-w-[85vw] bg-surface shadow-2xl lg:hidden"><MemberList community={community} onClose={()=>setMobileMembersOpen(false)}/></div></>}
  </div>;
}
