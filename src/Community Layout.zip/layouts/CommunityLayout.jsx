import { ArrowLeft, Compass, House, UsersRound } from "lucide-react";
import { Link, Outlet } from "react-router-dom";
import Logo from "../components/common/Logo";
import ThemeToggle from "../components/common/ThemeToggle";
import VoiceDock from "../features/communities/components/VoiceDock";
import { VoiceProvider } from "../features/communities/hooks/useVoiceSession";
import { useRealtime } from "../features/social/hooks/useRealtime";
export default function CommunityLayout() {
  useRealtime();
  return (
    <VoiceProvider>
      <div className="flex h-dvh min-h-0 flex-col overflow-hidden bg-canvas text-ink">
        <header className="z-30 shrink-0 border-b border-line bg-surface">
          <div className="mx-auto flex h-14 max-w-[1800px] items-center justify-between gap-2 px-3 sm:px-5">
            <div className="flex items-center gap-2">
              <Link
                to="/"
                aria-label="Back to AEVORA Home"
                className="grid size-9 place-items-center rounded-lg border border-line text-ink-soft"
              >
                <ArrowLeft size={18} />
              </Link>
              <Link to="/">
                <Logo size="sm" />
              </Link>
              <span className="hidden border-l border-line pl-3 text-sm font-bold sm:block">
                Communities
              </span>
            </div>
            <nav
              aria-label="Community navigation"
              className="flex items-center gap-1"
            >
              <Link
                to="/communities"
                className="rounded-lg px-2 py-2 text-sm text-ink-soft hover:bg-raised"
              >
                <Compass size={18} className="inline sm:mr-1" />
                <span className="hidden sm:inline">Discover</span>
              </Link>
              <Link
                to="/friends"
                className="rounded-lg px-2 py-2 text-sm text-ink-soft hover:bg-raised"
              >
                <UsersRound size={18} className="inline sm:mr-1" />
                <span className="hidden sm:inline">Friends</span>
              </Link>
              <Link
                to="/"
                className="rounded-lg px-2 py-2 text-sm text-ink-soft hover:bg-raised"
              >
                <House size={18} className="inline sm:mr-1" />
                <span className="hidden sm:inline">Home</span>
              </Link>
              <ThemeToggle />
            </nav>
          </div>
        </header>
        <main className="mx-auto flex min-h-0 w-full max-w-[1800px] flex-1 overflow-hidden">
          <Outlet />
        </main>
        <VoiceDock />
      </div>
    </VoiceProvider>
  );
}
